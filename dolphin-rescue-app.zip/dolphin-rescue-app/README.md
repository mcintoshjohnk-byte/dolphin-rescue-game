# Dolphin Rescue 🐬

A gentle, toddler-friendly ocean game built with React + Vite.

Free the dolphin from the seaweed, feed it five fish, meet the baby dolphin,
then help the baby sort the treasure gems into their matching color boxes.
No timers, no scores, no losing — every interaction is a win.

## Project structure

```
dolphin-rescue/
├── index.html            # HTML entry point
├── package.json
├── vite.config.js        # Vite + React plugin config
├── vercel.json           # Explicit Vercel build settings (optional; Vercel auto-detects Vite)
├── asset-manifest.json   # Catalog of every visual/audio asset in the game
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx          # React bootstrap
    ├── index.css         # Global shell styles (mobile drag/tap fixes)
    └── App.jsx           # The entire game (phase state machine + components + assets)
```

### Architecture notes

- The game is a **phase state machine**: `INTRO → SEAWEED_RESCUE → FEEDING →
  CELEBRATION → TREASURE_CHEST → NEXT_RESCUE → (loops)`. Each phase is one
  self-contained component registered in `PHASE_COMPONENTS`, with the flow
  defined by `PHASE_TRANSITIONS`. To add a new activity, add a phase entry,
  write one component, register it, and repoint two transition edges.
- Both dolphin images are **embedded as base64 data URIs** inside `App.jsx`,
  so the app is fully self-contained with no asset hosting concerns. If you
  prefer separate files, move them to `public/` and swap the constants for
  `<image href="/dolphin.png">` URLs.
- Sounds are **synthesized at runtime** with the Web Audio API — no audio
  files needed. Note that browsers block audio until the first user
  interaction; in this game a tap always precedes any sound, so it works.
- `asset-manifest.json` is the source of truth for all art/sound assets.

## Run locally

Prerequisites: Node.js 18+ (20+ recommended) and npm.

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server (hot reload)
npm run dev
# → open the printed URL, usually http://localhost:5173

# 3. Production build + local preview of that build
npm run build
npm run preview
```

## Deploy to Vercel

### Option A — Git integration (recommended)

1. Push this folder to a GitHub/GitLab/Bitbucket repository:
   ```bash
   git init
   git add .
   git commit -m "Dolphin Rescue"
   git remote add origin <your-repo-url>
   git push -u origin main
   ```
2. Go to [vercel.com](https://vercel.com), sign in, and click **Add New → Project**.
3. Import the repository. Vercel auto-detects **Vite** — the defaults
   (build command `npm run build`, output directory `dist`) are already
   correct, and `vercel.json` pins them explicitly.
4. Click **Deploy**. Every future `git push` redeploys automatically,
   and pull requests get preview URLs.

### Option B — Vercel CLI

```bash
npm install -g vercel
vercel          # first run: link/create the project, then deploys a preview
vercel --prod   # promote to production
```

That's it — the app is a fully static site (no server, no environment
variables, no database), so there is nothing else to configure.

## Tips

- **Best experienced on a touch device** — the fish and gems are drag-and-drop
  with large toddler-friendly targets, though mouse works fine too.
- If you later add client-side routing, add a rewrite in `vercel.json`
  (`{ "rewrites": [{ "source": "/(.*)", "destination": "/" }] }`).
